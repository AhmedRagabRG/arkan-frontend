import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-AO6PKZPJ.js";
import "./chunk-RBKVTBCD.js";
import "./chunk-6JZWX5A5.js";
import "./chunk-L27UBJGV.js";
import "./chunk-BVSBAIWK.js";
import "./chunk-LIE3BGQ6.js";
import "./chunk-CPZYF3UQ.js";
import "./chunk-6OGY2GNC.js";
import "./chunk-X5NLSII4.js";
import "./chunk-IGNQQJCH.js";
import "./chunk-DCYMPORG.js";
import "./chunk-LDODSSGN.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
