export interface IAppointment {
    name: string;
    phoneNumber: string;
    service: string;
    date: Date;
}