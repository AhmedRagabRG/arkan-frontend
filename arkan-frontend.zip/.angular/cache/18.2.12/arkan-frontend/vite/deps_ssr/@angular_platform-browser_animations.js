import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-CWWEJL25.js";
import "./chunk-AFPM6O4S.js";
import "./chunk-FGJMU7N7.js";
import "./chunk-OKBL27Y3.js";
import "./chunk-CPZYF3UQ.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-6OGY2GNC.js";
import "./chunk-X5NLSII4.js";
import "./chunk-IGNQQJCH.js";
import "./chunk-DCYMPORG.js";
import "./chunk-LDODSSGN.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
