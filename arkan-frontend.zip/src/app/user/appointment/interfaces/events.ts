export interface IEvent {
    title: string;
    date: string;
}

export interface IDate {
    name: string; 
    date: string;
}
