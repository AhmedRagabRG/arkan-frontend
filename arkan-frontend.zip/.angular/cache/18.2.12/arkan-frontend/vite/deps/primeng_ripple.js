import {
  Ripple,
  RippleModule
} from "./chunk-YUTF7F3A.js";
import "./chunk-BUGEQH7Q.js";
import "./chunk-KGEFRC3G.js";
import "./chunk-74DNM3LL.js";
import "./chunk-5O2IDK2E.js";
import "./chunk-4N4GOYJH.js";
import "./chunk-5OPE3T2R.js";
import "./chunk-FHTVLBLO.js";
import "./chunk-4MWRP73S.js";
export {
  Ripple,
  RippleModule
};
//# sourceMappingURL=primeng_ripple.js.map
